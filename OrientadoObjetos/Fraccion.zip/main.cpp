//Realiza el main para probar todos los operadores

void cargaDatos(ArrayFracc& misFracciones){
    //Llena con esta función los datos del objeto misFracciones
    //con la lectura de un archivo de texto
}
//Puedes crear más funciones si las requieres...

//Llena la función principal para hacer todas tus pruebas
int main(){
    //Crea dos fracciones con datos que recibas del usuario
    //Prueba los distintos operadores de la clase Fracción haz un menu para
    //que el usuario decida qué operación quiere realizar con estas dos fracciones
    //llena los datos de un ArrayFracc y prueba el operador de indexación
    return 0;
}